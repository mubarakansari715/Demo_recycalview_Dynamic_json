package com.example.profile_demo;

import android.content.Context;
import android.icu.util.ULocale;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Locale;
import java.util.zip.Inflater;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
     LayoutInflater inflater;
     ArrayList<javabeen> recyView;
     Context ctx;

    public Adapter(ArrayList<javabeen> recyView, Context ctx) {
        this.recyView = recyView;
        this.ctx = ctx;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.activity_content,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            holder.fname.setText(recyView.get(position).getFirst_name());
            holder.lname.setText(recyView.get(position).getLast_name());
            holder.email.setText(recyView.get(position).getEmail());
            Picasso.with(ctx).load(recyView.get(position).getAvatar()).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return recyView.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView fname,lname,email;
        ImageView imageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            fname = itemView.findViewById(R.id.tvname);
            lname = itemView.findViewById(R.id.tvlastname);
            email = itemView.findViewById(R.id.tvemail);
            imageView = itemView.findViewById(R.id.imgprofile);
        }
    }

}

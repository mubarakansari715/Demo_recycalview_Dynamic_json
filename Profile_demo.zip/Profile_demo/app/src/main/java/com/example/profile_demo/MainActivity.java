package com.example.profile_demo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DownloadManager;
import android.app.VoiceInteractor;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static android.content.ContentValues.TAG;

public class MainActivity extends AppCompatActivity {
    RecyclerView recView;
    LinearLayout linview;
    String cid,first_name,last_name,email,avatar;
    ArrayList<javabeen> arrayList = new ArrayList<>();
    Context ctx=this;
    private static String jsonusrl="https://reqres.in/api/users?page=1";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recView =findViewById(R.id.recView);
        arrayList =new ArrayList<>();
         RequestCard();
        Toast.makeText(MainActivity.this, "mm"+jsonusrl, Toast.LENGTH_SHORT).show();

    }

    private void RequestCard() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, jsonusrl, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 1; i < response.length(); i++) {
                    try {
                        javabeen adapter = new javabeen();
                        JSONObject object = response.getJSONObject(i);
//                        adapter.setId(object.getString("id").toString()));
                        cid = object.getString("id");
                        email = object.getString("email");
                        first_name = object.getString("first_name");
                        last_name = object.getString("last_name");
                        avatar = object.getString("avatar");

                        javabeen cat = new javabeen(cid, email, first_name, last_name, avatar);
                        arrayList.add(cat);

                        Adapter adapter1 = new Adapter(arrayList, ctx);
                        recView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                        recView.setItemAnimator(new DefaultItemAnimator());
                        recView.setLayoutManager(new GridLayoutManager(ctx, 1));
                        recView.setAdapter(adapter1);



                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG, "onErrorResponse: ");
            }
        });

        requestQueue.add(jsonArrayRequest);


    }

}